namespace JwtAuthDemo.Models;

    public class Transaction
{
    public DateTime Date { get; set; }
    public decimal Income { get; set; }
    public decimal Expenses { get; set; }
    public required string Details { get; set; }
    public decimal Total { get; set; }
    public decimal Balance { get; set; } 

    // Read-only computed property
    public decimal Amount => Income - Expenses;
}




