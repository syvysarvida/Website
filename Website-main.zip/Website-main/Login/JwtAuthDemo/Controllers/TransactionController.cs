using Microsoft.AspNetCore.Mvc;
using JwtAuthDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace JwtAuthDemo.Controllers
{
    public class TransactionController : Controller
    {
        private static List<Transaction> _transactions1 = new List<Transaction>();
        private static List<Transaction> _transactions2 = new List<Transaction>();
        private static List<Transaction> _transactions3 = new List<Transaction>();

        [HttpGet]
        public IActionResult Transaction1()
        {
            ViewData["Title"] = "Transaction 1";
            return View("TransactionView", _transactions1);
        }

        [HttpGet]
        public IActionResult Transaction2()
        {
            ViewData["Title"] = "Transaction 2";
            return View("TransactionView", _transactions2);
        }

        [HttpGet]
        public IActionResult Transaction3()
        {
            ViewData["Title"] = "Transaction 3";
            return View("TransactionView", _transactions3);
        }

        [HttpPost]
        public IActionResult UpdateTransaction(List<Transaction> updatedTransactions, Transaction newTransaction, string viewName)
        {
            List<Transaction> targetList = viewName switch
            {
                "Transaction1" => _transactions1 = new List<Transaction>(),
                "Transaction2" => _transactions2 = new List<Transaction>(),
                "Transaction3" => _transactions3 = new List<Transaction>(),
                _ => throw new ArgumentException("Invalid view name.")
            };

            foreach (var tx in updatedTransactions)
            {
                if (tx.Date == DateTime.MinValue && tx.Income == 0 && tx.Expenses == 0 && string.IsNullOrWhiteSpace(tx.Details))
                    continue;

                decimal lastBalance = targetList.LastOrDefault()?.Balance ?? 0;
                tx.Balance = lastBalance + tx.Income - tx.Expenses;
                tx.Total = tx.Balance;
                targetList.Add(tx);
            }

            if (newTransaction.Date != DateTime.MinValue || newTransaction.Income != 0 || newTransaction.Expenses != 0 || !string.IsNullOrWhiteSpace(newTransaction.Details))
            {
                decimal lastBalance = targetList.LastOrDefault()?.Balance ?? 0;
                newTransaction.Balance = lastBalance + newTransaction.Income - newTransaction.Expenses;
                newTransaction.Total = newTransaction.Balance;
                targetList.Add(newTransaction);
            }

            return RedirectToAction(viewName);
        }
    }
}
